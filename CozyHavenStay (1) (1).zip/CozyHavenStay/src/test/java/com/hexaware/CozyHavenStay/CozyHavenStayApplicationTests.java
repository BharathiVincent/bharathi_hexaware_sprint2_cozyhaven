package com.hexaware.CozyHavenStay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CozyHavenStayApplicationTests {

	@Test
	void contextLoads() {
	}

}
