package com.example.cozyHaven;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.LocalDate;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.example.cozyHaven.entity.*;
import com.example.cozyHaven.enums.BookingStatus;
import com.example.cozyHaven.enums.Role;
import com.example.cozyHaven.repo.UserRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CozyHavenApplicationTests {
	 @Test
	    void testNoArgsConstructor() {
	        Register register = new Register();
	        assertNotNull(register);
	    }
	   @Test
	    void testAllArgsConstructor() {
	        Long id = 1L;
	        String email = "test@example.com";
	        String password = "password123";
	        String phone = "1234567890";
	        String address = "123 Test St";

	        Register register = new Register(id, email, password, phone, address);

	        assertEquals(id, register.getId());
	        assertEquals(email, register.getEmail());
	        assertEquals(password, register.getPassword());
	        assertEquals(phone, register.getPhone());
	        assertEquals(address, register.getAddress());
	    }
	   @Test
	    void testGettersAndSetters() {
	        Register register = new Register();

	        Long id = 2L;
	        String email = "another@example.com";
	        String password = "newpassword";
	        String phone = "0987654321";
	        String address = "456 New Ave";

	        register.setId(id);
	        register.setEmail(email);
	        register.setPassword(password);
	        register.setPhone(phone);
	        register.setAddress(address);

	        assertEquals(id, register.getId());
	        assertEquals(email, register.getEmail());
	        assertEquals(password, register.getPassword());
	        assertEquals(phone, register.getPhone());
	        assertEquals(address, register.getAddress());
	    }
	 
	   
	   
	   private User testUser;
	    private Room testRoom;

	    @BeforeEach
	    void setUp() {
	        // Initialize mock or dummy User and Room objects for association testing
	        // In a real application, these might be retrieved from a test database or mocked with Mockito.
	        testUser = new User();
	        testUser.setId(1L);
	        testUser.setName("John Doe");

	        testRoom = new Room();
	        testRoom.setId(101L);
	        testRoom.setRoomSize("30 sqm");
	        testRoom.setBaseFare(100.00);
	    }
	    @Test
	    void testGettersAndSetters1() {
	        Booking booking = new Booking();

	        // Test setters
	        Long id = 5L;
	        LocalDate checkIn = LocalDate.of(2025, 8, 10);
	        LocalDate checkOut = LocalDate.of(2025, 8, 15);
	        int numRooms = 2;
	        int numAdults = 3;
	        int numChildren = 0;
	        double totalFare = 800.50;
	        BookingStatus status = BookingStatus.CONFIRMED;

	        booking.setId(id);
	        booking.setUser(testUser);
	        booking.setRoom(testRoom);
	        booking.setCheckInDate(checkIn);
	        booking.setCheckOutDate(checkOut);
	        booking.setNumberOfRooms(numRooms);
	        booking.setNumberOfAdults(numAdults);
	        booking.setNumberOfChildren(numChildren);
	        booking.setTotalFare(totalFare);
	        booking.setStatus(status);

	        // Test getters
	        assertEquals(id, booking.getId());
	        assertEquals(testUser, booking.getUser());
	        assertEquals(testRoom, booking.getRoom());
	        assertEquals(checkIn, booking.getCheckInDate());
	        assertEquals(checkOut, booking.getCheckOutDate());
	        assertEquals(numRooms, booking.getNumberOfRooms());
	        assertEquals(numAdults, booking.getNumberOfAdults());
	        assertEquals(numChildren, booking.getNumberOfChildren());
	        assertEquals(totalFare, booking.getTotalFare());
	        assertEquals(status, booking.getStatus());
	    }

	 	
}
