package com.example.cozyHaven; // Adjust package as per your project structure

import com.example.cozyHaven.entity.Register; // Adjust package as per your project structure
import com.example.cozyHaven.entity.RegisterRepo;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@DataJpaTest
public class RegisterRepoTest {

    @Autowired
    private RegisterRepo registerRepo;

    @Autowired
    private TestEntityManager entityManager;

    private Register testRegister; // This will hold the user we pre-save for tests
    @Test
    @DisplayName("Should return null/empty optional if Register ID does not exist")
    void testRegisterRetrievalById_NotFound() {
        // Given: A non-existent ID
        Long nonExistentId = 999L; // Assuming 999 is an ID that won't exist

        // When: Try to retrieve a user with a non-existent ID
        Register foundRegister = registerRepo.findById(nonExistentId).orElse(null);

        // Then: Assert that no user was found
        assertNull(foundRegister, "The Register object should be null for a non-existent ID");
    }

}