package com.example.cozyHaven.entity;
import jakarta.persistence.*;
import java.util.List; // To potentially store multiple image URLs

/**
 * Represents a hotel listed in the Cozy Haven Stay Hotel Booking System.
 */
@Entity
@Table(name = "hotels")
public class Hotel {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the hotel

    private String name; // Name of the hotel
    private String location; // Location of the hotel, for search purposes 
    private String images; // Stores paths or URLs to hotel images (can be a comma-separated string or JSON) 
    private String amenities; // Stores a string representing amenities (e.g., "Dining, parking, free Wi-Fi, Room Service, Swimming pool, Fitness center") 

    @ManyToOne(fetch = FetchType.LAZY) // Many hotels can be managed by one hotel owner
    @JoinColumn(name = "hotel_owner_id") // Foreign key column linking to the User entity
    private User hotelOwner; // The User who owns/manages this hotel (Role.HOTEL_OWNER) 

    // Constructors
    public Hotel() {
        // Default constructor required by JPA
    }

    public Hotel(String name, String location, String images, String amenities, User hotelOwner) {
        this.name = name;
        this.location = location;
        this.images = images;
        this.amenities = amenities;
        this.hotelOwner = hotelOwner;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getAmenities() {
        return amenities;
    }

    public void setAmenities(String amenities) {
        this.amenities = amenities;
    }

    public User getHotelOwner() {
        return hotelOwner;
    }

    public void setHotelOwner(User hotelOwner) {
        this.hotelOwner = hotelOwner;
    }

}
