package com.example.cozyHaven.enums;

public enum BookingStatus {
	 PENDING,    // Booking initiated, but not yet confirmed
	    CONFIRMED,  // Booking successfully confirmed
	    CANCELLED,  // Booking has been cancelled by user or administrator 
	    REFUNDED    // Refund has been processed for a cancelled booking 
	}


