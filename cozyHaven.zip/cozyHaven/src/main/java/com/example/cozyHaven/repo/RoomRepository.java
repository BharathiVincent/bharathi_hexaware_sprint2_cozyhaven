package com.example.cozyHaven.repo;

import com.example.cozyHaven.entity.Hotel; // Import the Hotel entity
import com.example.cozyHaven.entity.Room; // Import the Room entity
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {
	 /**
     * Finds all rooms belonging to a specific hotel.
     * @param hotel The Hotel entity.
     * @return A list of rooms in the specified hotel.
     */
    List<Room> findByHotel(Hotel hotel);

    /**
     * Finds rooms in a specific hotel that are available.
     * @param hotel The Hotel entity.
     * @param available Boolean indicating availability.
     * @return A list of available rooms in the specified hotel.
     */
    List<Room> findByHotelAndAvailable(Hotel hotel, boolean available);

    /**
     * Finds rooms by bed sizes and maximum people accommodated.
     * @param bedSizes The type of bed size (e.g., "double bed").
     * @param maxPeopleAccommodate The maximum number of people the room can accommodate.
     * @return A list of rooms matching the criteria.
     */
    List<Room> findByBedSizesAndMaxPeopleAccommodateGreaterThanEqual(String bedSizes, int maxPeopleAccommodate);

}
