package com.example.cozyHaven.enums;

public enum Role {
	 GUEST, // For regular travelers booking rooms 
	    HOTEL_OWNER, // For managing hotels and rooms 
	    ADMIN // For overall system administration 
}
