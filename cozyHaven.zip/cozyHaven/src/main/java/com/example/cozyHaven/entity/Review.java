package com.example.cozyHaven.entity;

import jakarta.persistence.*;

/**
 * Represents a review and rating left by a user for a hotel.
 */
@Entity
@Table(name = "reviews")
public class Review {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the review

    @ManyToOne(fetch = FetchType.LAZY) // Many reviews can be made by one user
    @JoinColumn(name = "user_id") // Foreign key column linking to the User entity
    private User user; // The user who left the review 

    @ManyToOne(fetch = FetchType.LAZY) // Many reviews can be for one hotel
    @JoinColumn(name = "hotel_id") // Foreign key column linking to the Hotel entity
    private Hotel hotel; // The hotel being reviewed 

    private int rating; // The rating given by the user (e.g., 1 to 5 stars) 
    @Column(columnDefinition = "TEXT") // Use TEXT for potentially longer comments
    private String comment; // The textual review or feedback 

    // Constructors
    public Review() {
        // Default constructor required by JPA
    }

    public Review(User user, Hotel hotel, int rating, String comment) {
        this.user = user;
        this.hotel = hotel;
        this.rating = rating;
        this.comment = comment;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Hotel getHotel() {
        return hotel;
    }

    public void setHotel(Hotel hotel) {
        this.hotel = hotel;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }
}
