package com.example.cozyHaven.repo;
import com.example.cozyHaven.entity.Hotel; // Import the Hotel entity
import com.example.cozyHaven.entity.Review; // Import the Review entity
import com.example.cozyHaven.entity.User; // Import the User entity
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for managing Review entities.
 */
@Repository
public interface ReviewRepository extends JpaRepository<Review, Long> {

    /**
     * Finds all reviews for a specific hotel.
     * @param hotel The Hotel entity.
     * @return A list of reviews for the specified hotel.
     */
    List<Review> findByHotel(Hotel hotel);

    /**
     * Finds all reviews made by a specific user.
     * @param user The User entity.
     * @return A list of reviews submitted by the specified user.
     */
    List<Review> findByUser(User user);

    /**
     * Finds a specific review by a user for a hotel.
     * Useful for checking if a user has already reviewed a hotel.
     * @param user The User entity.
     * @param hotel The Hotel entity.
     * @return An Optional containing the Review if found, or empty otherwise.
     */
    Optional<Review> findByUserAndHotel(User user, Hotel hotel);

    /**
     * Finds reviews for a hotel with a rating greater than or equal to the specified value.
     * @param hotel The Hotel entity.
     * @param rating The minimum rating.
     * @return A list of reviews matching the criteria.
     */
    List<Review> findByHotelAndRatingGreaterThanEqual(Hotel hotel, int rating);
}