package com.example.cozyHaven.repo;
import com.example.cozyHaven.entity.*;
import  com.example.cozyHaven.enums.Role; // Import the Role enum
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Repository interface for managing User entities.
 */
@Repository
public interface UserRepository {
	  /**
     * Finds a user by their email address.
     * @param email The email address of the user.
     * @return An Optional containing the User if found, or empty otherwise.
     */
    Optional<User> findByEmail(String email);

    /**
     * Finds users by their role.
     * @param role The role of the users (e.g., GUEST, HOTEL_OWNER, ADMIN).
     * @return A list of users with the specified role.
     */
    List<User> findByRole(Role role);

    /**
     * Checks if a user with the given email exists.
     * @param email The email address to check.
     * @return True if a user with the email exists, false otherwise.
     */
    boolean existsByEmail(String email);



}
