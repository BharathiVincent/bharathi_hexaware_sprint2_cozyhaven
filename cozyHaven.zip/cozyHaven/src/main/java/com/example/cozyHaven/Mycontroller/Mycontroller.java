package com.example.cozyHaven.Mycontroller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.cozyHaven.entity.*;
@Controller
public class Mycontroller {
	@Autowired
	RegisterRepo registerRepo;
	@GetMapping("/")
	public String fun1()
	{
		return "Index.jsp";
	}
	@PostMapping("/register")
	public String fun2(Register register,Model model)
	{	
		System.out.println("Register="+register);
		model.addAttribute("email", register.getEmail());
		model.addAttribute("password", register.getPassword());
		model.addAttribute("phone", register.getPhone());
		model.addAttribute("address", register.getAddress());
		System.out.println("registerRepo:\t"+registerRepo);
		
		registerRepo.save(register);
		
		List<Register> users=registerRepo.findAll();
		model.addAttribute("users", users);
		
		return "Success.jsp";
	}

	 

}




