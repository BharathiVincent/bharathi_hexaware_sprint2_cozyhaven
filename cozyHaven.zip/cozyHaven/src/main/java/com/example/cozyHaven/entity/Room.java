package com.example.cozyHaven.entity;

import jakarta.persistence.*;

/**
 * Represents a room available in a hotel.
 */
@Entity
@Table(name = "rooms")
public class Room {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id; // Unique identifier for the room

	    @ManyToOne(fetch = FetchType.LAZY) // Many rooms belong to one hotel
	    @JoinColumn(name = "hotel_id") // Foreign key column linking to the Hotel entity
	    private Hotel hotel; // The hotel this room belongs to

	    private String roomSize; // e.g., "70 m²/753 ft²" 
	    private String bedSizes; // e.g., "single bed", "double bed", "king size" 
	    private int maxPeopleAccommodate; // Maximum number of people the room can accommodate 
	    private double baseFare; // Base price of the room 
	    private boolean ac; // True if AC, false if Non-AC 
	    // Note: Availability for specific dates would typically be handled dynamically or in a separate availability table,
	    // but a basic 'available' status can indicate if the room is generally active for booking.
	    private boolean available; // Indicates if the room is generally available for booking 

	    // Constructors
	    public Room() {
	        // Default constructor required by JPA
	    }

	    public Room(Hotel hotel, String roomSize, String bedSizes, int maxPeopleAccommodate, double baseFare, boolean ac, boolean available) {
	        this.hotel = hotel;
	        this.roomSize = roomSize;
	        this.bedSizes = bedSizes;
	        this.maxPeopleAccommodate = maxPeopleAccommodate;
	        this.baseFare = baseFare;
	        this.ac = ac;
	        this.available = available;
	    }

	    // Getters and Setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public Hotel getHotel() {
	        return hotel;
	    }

	    public void setHotel(Hotel hotel) {
	        this.hotel = hotel;
	    }

	    public String getRoomSize() {
	        return roomSize;
	    }

	    public void setRoomSize(String roomSize) {
	        this.roomSize = roomSize;
	    }

	    public String getBedSizes() {
	        return bedSizes;
	    }

	    public void setBedSizes(String bedSizes) {
	        this.bedSizes = bedSizes;
	    }

	    public int getMaxPeopleAccommodate() {
	        return maxPeopleAccommodate;
	    }

	    public void setMaxPeopleAccommodate(int maxPeopleAccommodate) {
	        this.maxPeopleAccommodate = maxPeopleAccommodate;
	    }

	    public double getBaseFare() {
	        return baseFare;
	    }

	    public void setBaseFare(double baseFare) {
	        this.baseFare = baseFare;
	    }

	    public boolean isAc() {
	        return ac;
	    }

	    public void setAc(boolean ac) {
	        this.ac = ac;
	    }

	    public boolean isAvailable() {
	        return available;
	    }

	    public void setAvailable(boolean available) {
	        this.available = available;
	    }

}
