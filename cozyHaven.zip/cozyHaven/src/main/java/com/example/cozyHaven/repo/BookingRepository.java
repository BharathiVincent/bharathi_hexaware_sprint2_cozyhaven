package com.example.cozyHaven.repo;
import com.example.cozyHaven.entity.Booking; // Import the Booking entity
import com.example.cozyHaven.entity.Room; // Import the Room entity
import com.example.cozyHaven.entity.User; // Import the User entity
import com.example.cozyHaven.enums.BookingStatus; // Import the BookingStatus enum
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

/**
 * Repository interface for managing Booking entities.
 */
@Repository

public interface BookingRepository extends JpaRepository<Booking, Long> {
	  /**
     * Finds all bookings made by a specific user.
     * @param user The User entity (guest).
     * @return A list of bookings made by the specified user.
     */
    List<Booking> findByUser(User user);

    /**
     * Finds bookings for a specific room within a date range.
     * This can be used for checking room availability.
     * @param room The Room entity.
     * @param checkInDate The check-in date.
     * @param checkOutDate The check-out date.
     * @return A list of bookings for the specified room within the dates.
     */
    List<Booking> findByRoomAndCheckInDateBeforeAndCheckOutDateAfter(Room room, LocalDate checkOutDate, LocalDate checkInDate);

    /**
     * Finds bookings by their status.
     * @param status The status of the booking (e.g., CONFIRMED, CANCELLED).
     * @return A list of bookings with the specified status.
     */
    List<Booking> findByStatus(BookingStatus status);

    /**
     * Finds bookings for a specific hotel (via room's hotel) within a date range.
     * Note: This might require a `@Query` annotation for more complex joins if not directly supported by method name.
     * For simplicity, this example assumes direct relationships or basic queries.
     * A more robust solution might involve joining on Room.hotel.
     */
    // Example of a custom query if needed:
    // @Query("SELECT b FROM Booking b WHERE b.room.hotel = :hotel AND b.checkInDate <= :checkOutDate AND b.checkOutDate >= :checkInDate")
    // List<Booking> findByHotelAndDates(@Param("hotel") Hotel hotel, @Param("checkInDate") LocalDate checkInDate, @Param("checkOutDate") LocalDate checkOutDate);

}
