package com.example.cozyHaven.entity;
import com.example.cozyHaven.enums.BookingStatus; // Import the BookingStatus enum
import jakarta.persistence.*;
import java.time.LocalDate;
@Entity
@Table(name = "bookings")
public class Booking {
	 @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id; // Unique identifier for the booking

	    @ManyToOne(fetch = FetchType.LAZY) // Many bookings can be made by one user
	    @JoinColumn(name = "user_id") // Foreign key column linking to the User entity
	    private User user; // The guest who made the booking 

	    @ManyToOne(fetch = FetchType.LAZY) // Many bookings can be for one room
	    @JoinColumn(name = "room_id") // Foreign key column linking to the Room entity
	    private Room room; // The room that has been booked 

	    private LocalDate checkInDate; // The check-in date for the booking 
	    private LocalDate checkOutDate; // The check-out date for the booking 
	    private int numberOfRooms; // Number of rooms booked in this reservation 
	    private int numberOfAdults; // Number of adults included in the booking 
	    private int numberOfChildren; // Number of children included in the booking 
	    private double totalFare; // Calculated total fare for the booking 

	    @Enumerated(EnumType.STRING)
	    private BookingStatus status; // Current status of the booking (e.g., PENDING, CONFIRMED, CANCELLED, REFUNDED) 

	    // Constructors
	    public Booking() {
	        // Default constructor required by JPA
	    }

	    public Booking(User user, Room room, LocalDate checkInDate, LocalDate checkOutDate, int numberOfRooms, int numberOfAdults, int numberOfChildren, double totalFare, BookingStatus status) {
	        this.user = user;
	        this.room = room;
	        this.checkInDate = checkInDate;
	        this.checkOutDate = checkOutDate;
	        this.numberOfRooms = numberOfRooms;
	        this.numberOfAdults = numberOfAdults;
	        this.numberOfChildren = numberOfChildren;
	        this.totalFare = totalFare;
	        this.status = status;
	    }

	    // Getters and Setters
	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public User getUser() {
	        return user;
	    }

	    public void setUser(User user) {
	        this.user = user;
	    }

	    public Room getRoom() {
	        return room;
	    }

	    public void setRoom(Room room) {
	        this.room = room;
	    }

	    public LocalDate getCheckInDate() {
	        return checkInDate;
	    }

	    public void setCheckInDate(LocalDate checkInDate) {
	        this.checkInDate = checkInDate;
	    }

	    public LocalDate getCheckOutDate() {
	        return checkOutDate;
	    }

	    public void setCheckOutDate(LocalDate checkOutDate) {
	        this.checkOutDate = checkOutDate;
	    }

	    public int getNumberOfRooms() {
	        return numberOfRooms;
	    }

	    public void setNumberOfRooms(int numberOfRooms) {
	        this.numberOfRooms = numberOfRooms;
	    }

	    public int getNumberOfAdults() {
	        return numberOfAdults;
	    }

	    public void setNumberOfAdults(int numberOfAdults) {
	        this.numberOfAdults = numberOfAdults;
	    }

	    public int getNumberOfChildren() {
	        return numberOfChildren;
	    }

	    public void setNumberOfChildren(int numberOfChildren) {
	        this.numberOfChildren = numberOfChildren;
	    }

	    public double getTotalFare() {
	        return totalFare;
	    }

	    public void setTotalFare(double totalFare) {
	        this.totalFare = totalFare;
	    }

	    public BookingStatus getStatus() {
	        return status;
	    }

	    public void setStatus(BookingStatus status) {
	        this.status = status;
	    }

}
