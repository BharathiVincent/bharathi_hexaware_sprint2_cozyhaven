package com.example.cozyHaven.repo;
import com.example.cozyHaven.entity.Hotel; // Import the Hotel entity
import com.example.cozyHaven.entity.User; // Import the User entity (for hotel owner)
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface HotelRepository extends JpaRepository<Hotel, Long> {

    /**
     * Finds hotels by their location.
     * @param location The location to search for hotels.
     * @return A list of hotels in the specified location.
     */
    List<Hotel> findByLocationContainingIgnoreCase(String location);

    /**
     * Finds all hotels managed by a specific hotel owner.
     * @param hotelOwner The User entity representing the hotel owner.
     * @return A list of hotels owned by the specified user.
     */
    List<Hotel> findByHotelOwner(User hotelOwner);

    /**
     * Finds a hotel by its name, ignoring case.
     * @param name The name of the hotel to search for.
     * @return An Optional containing the Hotel if found, or empty otherwise.
     */
    Optional<Hotel> findByNameIgnoreCase(String name);
}