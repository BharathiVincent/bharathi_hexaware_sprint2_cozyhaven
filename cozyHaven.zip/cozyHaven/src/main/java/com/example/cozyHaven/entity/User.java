package com.example.cozyHaven.entity;

import com.example.cozyHaven.enums.Role; // Import the Role enum
import jakarta.persistence.*;
@Entity
@Table(name = "users")
public class User {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id; // Unique identifier for the user

    private String name; // User's full name 
    private String email; // Used for login/username 
    private String password; // User's password (should be stored securely, e.g., hashed) 
    private String gender; // User's gender 
    private String contactNumber; // User's contact number 
    private String address; // User's address 

    @Enumerated(EnumType.STRING)
    private Role role; // Defines the user's role: GUEST, HOTEL_OWNER, ADMIN 

    // Constructors
    public User() {
        // Default constructor required by JPA
    }

    public User(String name, String email, String password, String gender, String contactNumber, String address, Role role) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.address = address;
        this.role = role;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Role getRole() {
        return role;
    }

    public void setRole(Role role) {
        this.role = role;
    }

}
